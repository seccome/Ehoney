1. 修改conf/agent.json 中的strategyAddr 和strategyPass 值为正确的redis host地址和密码
2. 修改conf/agent.json sshKeyUploadUrl 值为正确的欺骗防御web端host地址
3. nohup ./decept-agent & 启动  
4. 如果探针与蜜网不在同一网段、需同时配置honeyPublicIp 的值
#######################################################
注意
1. 注意同一台机器不能同时启动两个 decept-agent 除非修改conf/agent
2. 此agent不要部署在web端所在的机器
3. 部署机器需安装lsof
