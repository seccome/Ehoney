1. 修改conf/agent.json 中的strategyAddr 值为正确的redis host地址
2. 修改conf/agent.json sshKeyUploadUrl 值为正确的欺骗防御web端host地址
3. nohup ./decept-agent & 启动  

########################
注意
1. 注意同一台机器不能同时启动两个 decept-agent 除非修改conf/agent
2. 此agent 尽量不要部署在web端所在的机器

