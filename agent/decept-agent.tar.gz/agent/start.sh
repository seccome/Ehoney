#!/bin/bash

FILE_PATH=./conf/agent.json
B="strategyAddr"
r_ip="11"
r_port="22"

while read line
do
    result=$(echo $line | grep "${B}")
    if  [ "$result" != "" ]; then
        r_ip=$(echo $result| grep -P '((2(5[0-5]|[0-4]\d))|[0-1]?\d{1,2})(\.((2(5[0-5]|[0-4]\d))|[0-1]?\d{1,2})){3}' -o)
        portM=$(echo $result| grep -P ':[\d]+' -o)
        r_port=${portM#*:}
        printf "find redis ip: $r_ip port: $r_port \n"
    fi
done < $FILE_PATH

result=`nmap -sT ${r_ip} -p ${r_port}| grep open`
echo $result
if [ "$result" != "" ]; then
    printf "Remote Redis Service Is Enabled \n"
else
    echo "Remote Redis Service Is Not Connectable! Please Check!!"
fi

printf "starting agent... \n"

agent="agent"
proxy="proxy"
bait="bait"


# hosteye_agent
if ps -ef | grep $agent | egrep -v grep >/dev/null; then
        printf "$agent is started! \n"
        ps -ef | grep $agent | egrep -v grep | cut -c 9-16 | xargs kill -9

        if ps -ef | grep $agent | egrep -v grep >/dev/null; then
    		  printf "$agent killed error! \n"
    	  else
    		  printf "$agent killed success! \n"
        fi
else
    printf "$agent not found! \n"
fi


# proxy search kill
if ps -ef | grep $proxy | egrep -v grep >/dev/null; then
        printf "$proxy is started! \n"
        ps -ef | grep $proxy | egrep -v grep | cut -c 9-16 | xargs kill -9
        if ps -ef | grep $proxy | egrep -v grep >/dev/null; then
            printf "$proxy killed error! \n"
        else
            printf "$proxy killed success! \n"
        fi
else
    printf "$proxy not found! \n"
fi


# bait search kill
if ps -ef | grep $bait | egrep -v grep >/dev/null; then
        printf "$bait is started! \n"
        ps -ef | grep $bait | egrep -v grep | cut -c 9-16 | xargs kill -9

        if ps -ef | grep $bait | egrep -v grep >/dev/null; then
            printf "$bait killed error! \n"
        else
            printf "$bait killed success! \n"
        fi
else
    printf "$bait not found! \n"
fi


nohup ./hosteye_agent &