目录说明：
一、src
    decept-agent-win 底层源码，主要是用go编写，目录结构如下：
    --agent      客户端相关代码
      --bait     诱饵蜜签管理
      --conf     探针配置
	  --log      日志
      --proxy    代理管理
       

    --github.com 第三库的引入
    --golang.org 第三库的引入
    --gopkg.in 第三库的引入

    --util   公共工具
      --comm        公用代码
  

    使用：
		启动：start /b decept-agent.exe 后台启动 或  start decept-agent.exe
		停止：1. 查找agent的pid：tasklist | findstr decept-agent
			  2. taskkill /pid {pid} -t -f

    查看日志：
        cat bin/agent/log/agent.log  agent日志

Agent配置文件字段说明
{
                            
    "certFile": "cert/client-crt.pem",        //客户端证书公钥
    "keyFile": "cert/client-privatekey.pem",  //客户端证书私钥
    "CaFile": "cert/ca-crt.pem",              //ca证书公钥
    "authAddr":"43.227.67.203:5001",          //认证服务器地址
    "commAddr":"43.227.67.203:18787",         //通信服务器地址
    "policyAddr":"localhost:6379"             //策略服务器地址
}
{
  "honeyPublicIp": "",                    //蜜网的公网IP
  "strategyAddr": "127.0.0.1:6379",       //蜜网下发策略使用的Redis地址
  "strategyPass": "ehoney@0571",          //蜜网下发策略使用的Redis密码
  "version": "1.0",
  "heartbeatChannel": "agent-heart-beat-channel",  //心跳使用的Redis Channel 名称
  "sshKeyUploadUrl": "http://127.0.0.1:8082/deceptdefense/api/insertsshkey?t=1622516895107"   //协议代理上报SshKey的接口,只有协议代理才会用到
}

五、其他说明

1. 修改conf/agent.json 中的strategyAddr 和strategyPass 值为正确的redis host地址和密码
2. 修改conf/agent.json sshKeyUploadUrl 值为正确的欺骗防御web端host地址
3. nohup ./decept-agent & 启动  
4. 如果探针与蜜网不在同一网段、需同时配置honeyPublicIp 的值
#######################################################
注意
1. 注意同一台机器不能同时启动两个 decept-agent 除非修改conf/agent
2. 此agent不要部署在web端所在的机器

